from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Carro


def lista_carros(request):
    if request.method == 'POST':
        # --- AÇÃO: CADASTRAR NOVO VEÍCULO ---
        if 'cadastrar' in request.POST:
            placa = request.POST.get('placa', '').upper().strip()
            cor = request.POST.get('cor')
            escritorio = request.POST.get('escritorio')

            # Validação: impede duplicata de placa no banco de dados
            if Carro.objects.filter(placa=placa).exists():
                messages.error(request, f"Erro: A placa {placa} já está cadastrada no sistema!")
            else:
                Carro.objects.create(
                    placa=placa,
                    cor=cor,
                    escritorio=escritorio,
                    status='pre_localizado'
                )
                messages.success(request, f"Veículo {placa} cadastrado com sucesso!")

        # --- AÇÃO: MOVER PARA A PRÓXIMA FASE ---
        elif 'proxima_fase' in request.POST:
            carro_id = request.POST.get('carro_id')
            carro = get_object_or_404(Carro, id=carro_id)

            if carro.status == 'pre_localizado':
                carro.status = 'localizado'
                messages.info(request, f"Veículo {carro.placa} movido para 'Localizados'.")
            elif carro.status == 'localizado':
                carro.status = 'apreendido'
                messages.info(request, f"Veículo {carro.placa} movido para 'Apreendidos'.")

            carro.save()

        # --- AÇÃO: EXCLUIR VEÍCULO DO BANCO ---
        elif 'excluir' in request.POST:
            carro_id = request.POST.get('carro_id')
            carro = get_object_or_404(Carro, id=carro_id)
            placa_removida = carro.placa
            carro.delete()
            messages.warning(request, f"Veículo {placa_removida} foi removido permanentemente.")

        return redirect('lista_carros')

    # Busca todos os carros para exibir nas abas do template
    carros = Carro.objects.all()
    return render(request, 'carros/lista.html', {'carros': carros})